package com.example.pomodorotimer

import android.app.Service
import android.content.Intent
import android.os.CountDownTimer
import android.os.IBinder
import android.util.Log

class CountDownService : Service() { /*шаблон для создания объекта*/

    var bi = Intent(COUNTDOWN_BR) /*Для обычных изменяемых переменных*/

    private lateinit var timer: CountDownTimer /*Общедоступный класс, переменные которого нельзя инициализировать сразу*/

    override fun onCreate() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        super.onCreate() /*обозначает суперкласс, т. е. класс, производным от которого является текущий класс.*/
        return super.onCreate() /*Возвращает к суперклассу*/
    }

    override fun onDestroy() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        super.onDestroy() /*обозначает суперкласс, т. е. класс, производным от которого является текущий класс.*/

        timer.cancel() /*нужен для удаления себя из очереди задач*/

        bi.putExtra("forceStopped", true) /*запись в bi*/
        sendBroadcast(bi) /*отправляет в обьект*/

        return super.onDestroy() /*Возвращает к суперклассу*/
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/

        var secToCount: Long = intent?.getLongExtra("toCount", -1) ?: -1 /*Для обычных изменяемых переменных, */
        secToCount++  /* +1 секунда, чтобы избежать завершения некоторых сервисов телефона до того, как наш собственный класс таймера достигнет 0 */


        try { /*определяет блок кода, в котором может произойти исключение*/

            timer = object:CountDownTimer(secToCount*1000, 1000) {  /* обратный отсчёт по секунде за раз*/
                override fun onTick(millisUntilFinished: Long) { /*показавыет сколько миллисекунд осталось*/

                    var msRemain:Long = millisUntilFinished /*сколько осталось миллисекунд до конца*/

                    Log.i("timerapp", msRemain.toString())
                    bi.putExtra("toCount", msRemain) /*запись в bi*/
                    sendBroadcast(bi) /*отправляет в обьект*/
                }

                override fun onFinish() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/

                    Log.i("timerapp", "timer finish")
                    bi.putExtra("toCount", -1.toLong()) /*запись в bi*/
                    sendBroadcast(bi) /*отправляет в обьект*/
                }
            }

            timer.start() /*для старта таймера*/

        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }


        return super.onStartCommand(intent, flags, startId) /*возврат к суперклассу*/
    }

    override fun onBind(arg0: Intent?): IBinder? { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        return null /*говорит что мы намеренно возвращаем null и у нас для этого есть причины.*/
    }

    companion object { /*это объект, который объявлен в том же файле, что и класс, и имеет то же имя, что и класс.*/
        const val COUNTDOWN_BR = "CountDownService.countdown_br" /*COUNTDOWN_BR - станет приватной переменной, для доступа к которой будет создан геттер. переменная будет заинлайнена, то есть компилятор заменит все полученные значения этой переменной на само значение.*/
    }
}