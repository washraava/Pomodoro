package com.example.pomodorotimer

enum class WorkState(val value: Int){ /*перечисление*/
    Work(0),
    Break(1);

    companion object{ /*возврат значения*/
        fun getValueFromInt(value: Int) = WorkState.values().first{
            it.value == value
        }
    }
}