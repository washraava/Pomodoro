package com.example.pomodorotimer


class Timer{

    private var hourToCount: Int = 0 /*час*/
    private var minToCount: Int = 0 /*минута*/
    private var secondToCount: Int = 0 /*секунда*/

    var isCounting = false /**/
    var isPause = false
    /*нам не нужна третья переменная, хранящая isStop, потому что isStop будет истинным, когда таймер не считает и таймер не останавливается*/

    var workState = WorkState.Work /*по умолчанию запуск с таймером работы*/

    /*подсчёт в минутах*/
    var breakTimer: Int = 0
    var workTimer: Int = 0

    /*таймер перерыва*/
    fun loadBreakTimer() {

        hourToCount = 0
        minToCount = breakTimer
        secondToCount = 0
    }
    /*таймер работы*/
    fun loadWorkTimer() {

        hourToCount = 0
        minToCount = workTimer
        secondToCount = 0
    }

    /*вывод времени на дисплей*/
    fun displayTime(): String {

        var result = ""

        var hr = hourToCount.toString() /*присвоение*/
        var min = minToCount.toString() /*присвоение*/
        var sec = secondToCount.toString() /*присвоение*/

        if (hourToCount > 0) {
            result += (if (hr.length < 2) hr.padStart(2, '0') else hr) + ":"
        }

        result += (if (min.length < 2) min.padStart(2, '0') else min) + ":"
        result += if (sec.length < 2) sec.padStart(2, '0') else sec

        return result
    }
    /*расчёт секунд*/
    fun toSeconds(): Long {

        return hourToCount.toLong() * 60 * 60 + minToCount.toLong() * 60 + secondToCount.toLong()
    }
    /*расчёт от секунд*/
    fun restoreFromSeconds(s:Long){
        secondToCount = (s % 60).toInt()
        minToCount = (((s-secondToCount)/60) % 60).toInt()
        hourToCount = ((s-secondToCount-minToCount*60)/3600).toInt()
    }
    /*расчёт минут,секунд, часов*/
    fun minusOneSecond() {

        if (hourToCount == 0 && minToCount == 0 && secondToCount <= 1) {
            secondToCount = 0
            isCounting = false
            return
        }

        if (secondToCount == 0 && minToCount > 0) {
            secondToCount = 60
            minToCount--

        } else if (secondToCount == 0 && minToCount == 0) {
            secondToCount = 60
            minToCount = 60
            hourToCount--
        }
        secondToCount--

    }

    /*Перезагрузка таймера*/
    fun resetTimer(){
        isCounting = false
        isPause = false
        /*сброс таймера и возврат в стандартное сострояние*/
        workState = WorkState.Work
        secondToCount=0
        minToCount= workTimer
        hourToCount=0
    }
}