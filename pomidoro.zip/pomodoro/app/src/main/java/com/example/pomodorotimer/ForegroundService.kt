package com.example.pomodorotimer

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat.Builder


class ForegroundService : Service() { /*шаблон для создания объекта*/

    var timerStarted = false /*Для обычных изменяемых переменных*/
    var bi = Intent(ForegroundService.COUNTDOWN_BR) /*Для обычных изменяемых переменных*/

    private lateinit var timer: CountDownTimer /*Общедоступный класс, переменные которого нельзя инициализировать сразу*/


    override fun onCreate() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        super.onCreate() /*обозначает суперкласс, т. е. класс, производным от которого является текущий класс.*/
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {


        if (timerStarted){ /*запрет на создание нескольких таймеров*/
            return START_NOT_STICKY /*запрет на создание нескольких таймеров*/
        }

        try { /*определяет блок кода, в котором может произойти исключение*/

            timer = object: CountDownTimer(Integer.MAX_VALUE.toLong(), 1000) {  // counting down 1s at a time
                override fun onTick(millisUntilFinished: Long) {

                    var msRemain:Long = millisUntilFinished /*Для обычных изменяемых переменных*/


                    bi.putExtra("toCount", msRemain) /*считает количество минут*/
                    sendBroadcast(bi) /*отправляет к обьекту*/
                }

                override fun onFinish() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/

                    Log.i("timerapp", "timer finish") /*запись в логи*/
                }
            }

            timer.start() /*запуск таймера*/
            timerStarted = true /*запуск таймера*/

        } catch (e: InterruptedException) { /*для обработки исключений в программе*/
            Thread.currentThread().interrupt() /*для обработки исключений в программе*/
        }


        createNotificationChannel() /*Код для уведомления пользователя*/
        val notificationIntent = Intent(this, MainActivity::class.java) /*Код для уведомления пользователя*/
        val pendingIntent = PendingIntent.getActivity( /*Код для уведомления пользователя*/
            this, /*Код для уведомления пользователя*/
            0, notificationIntent, 0 /*Код для уведомления пользователя*/
        )
        val notification: Notification = /*Код для уведомления пользователя*/
            Builder(this, CHANNEL_ID) /*Код для уведомления пользователя*/
                .setContentTitle("Timer On, Lets Go") /*Код для уведомления пользователя*/
                .setContentText("Hasta la vista, baby!") /*Код для уведомления пользователя*/
                .setSmallIcon(R.drawable.timericon) /*Код для уведомления пользователя*/
                .setContentIntent(pendingIntent) /*Код для уведомления пользователя*/
                .build() /*Код для уведомления пользователя*/
        startForeground(9000, notification) /*Код для уведомления пользователя*/

        return START_NOT_STICKY /*возврат к константе*/
    }

    override fun onDestroy() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        super.onDestroy() /*обозначает суперкласс, т. е. класс, производным от которого является текущий класс.*/

        if (timerStarted){ /*проверяет запущен ли таймер*/
            timer.cancel() /*и отключает его*/
        }

        bi.putExtra("forceStopped", true) /*запись в bi*/
        sendBroadcast(bi) /*отправляет в обьект*/
    }

    override fun onBind(intent: Intent): IBinder? { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        return null /*говорит что мы намеренно возвращаем null и у нас для этого есть причины.*/
    }
    /*отправка уведомлений*/
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Foreground Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(
                NotificationManager::class.java
            )
            manager.createNotificationChannel(serviceChannel)
        }
    }

    companion object {
        const val CHANNEL_ID = "ForegroundServiceChannel" /*константа*/
        const val COUNTDOWN_BR = "ForegounrdService.countdown_br" /*константа*/

    }
}