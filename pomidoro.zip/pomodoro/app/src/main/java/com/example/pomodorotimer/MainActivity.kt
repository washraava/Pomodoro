package com.example.pomodorotimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.*
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.preference.PreferenceManager
import android.util.Log
import android.view.Gravity
import android.view.Menu
import android.view.MenuInflater
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() { /*шаблон для создания объекта*/

    private var timer = Timer() /*переменные*/
    private val channelId = "pomodoroTimer" /*переменные*/
    lateinit var wakeLock: PowerManager.WakeLock /*переменные*/
    private var completed = 0 /*переменные*/





    private fun createNotificationChannel() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {  /*создание NotificationChannel выше API 26+ потому что это новый класс который не поддерживает старые версии*/
            val name = getString(R.string.channel_name) /*неизменяемые переменные*/
            val descriptionText = getString(R.string.channel_description) /*неизменяемые переменные*/
            val importance = NotificationManager.IMPORTANCE_DEFAULT /*неизменяемые переменные*/
            val channel = NotificationChannel(channelId, name, importance).apply { /*неизменяемые переменные*/
                description = descriptionText /*описание*/
            }
            /*Регистрация канала в системе*/
            val notificationManager: NotificationManager =  /*Регистрация канала в системе*/
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager  /*Регистрация канала в системе*/
            notificationManager.createNotificationChannel(channel)  /*Регистрация канала в системе*/
        }
    }


    private fun sendNotification() { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/


        with(NotificationManagerCompat.from(this)) {  /*Отмена последнего уведомления*/
            cancel(completed - 1)  /*Отмена последнего уведомления*/
        }

        val notificationIntent = Intent(this, MainActivity::class.java).apply { /*неизменяемые переменные*/
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK /*True если одна из переменных true*/
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0)

        val notification: Notification = /*настройка уведомлений*/
            NotificationCompat.Builder(this, channelId)
                .setContentTitle("Session $completed Completed")
                .setContentText("Yippee ki yay")
                .setSmallIcon(R.drawable.timericon)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()


        with(NotificationManagerCompat.from(this)) {
            notify(completed, notification) /*это уникальный int для каждого уведомления, которое вы должны определить*/
        }
    }

    private fun makeToast(message: String) { /*Показывает уведомление сверху*/

        val toast = Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.TOP, 0, 200)
        toast.show()

    }

    override fun onCreate(savedInstanceState: Bundle?) { /*возможность реализовать метод так, чтобы он имел идентичную сигнатуру с методом класса-предка, Объявление функции начинается с ключевого слова fun, затем идёт имя функции, в круглых скобках указываются параметры.*/



        super.onCreate(savedInstanceState) /*используется тогда, когда подклассу требуется сослаться на его непосредственный супер класс*/
        setContentView(R.layout.activity_main) /*устанавливает activity*/
        setSupportActionBar(toolbar) /*добавляет доп активность*/
        supportActionBar?.setDisplayHomeAsUpEnabled(true) /*включает функцию*/

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); /*Вертикальная ориентация*/

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) /*оставлять на экране уведомление*/

        textView_completed.setText(completed.toString()) /*показывать уведомление о завершении задачи*/

        createNotificationChannel() /*показывает уведомление*/

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager /*позволяет работать приложению после удаления из даспетчера задач*/
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "pomodoroTimer::wakeLock"
        )

        /*Отображает выбранные варианты*/
        val sharedPref = getPreferences(Context.MODE_PRIVATE) ?: return
        val savedWorkTimer = sharedPref.getInt("WORK",0)
        val savedBreakTimer = sharedPref.getInt("BREAK",0)

        editText_pomodoro.setText(savedWorkTimer.toString())
        editText_break.setText(savedBreakTimer.toString())

        Log.i("sharedPref","work $savedWorkTimer")
        Log.i("sharedPref","break $savedBreakTimer")


        timer.workTimer = savedWorkTimer /*присваивание значения переменной*/
        timer.breakTimer = savedBreakTimer /*присваивание значения переменной*/
        timer.loadWorkTimer() /*загрузка таймера*/
        textView_countdown.text = timer.displayTime() /*показывает оставшиеся время таймера*/
        setTimerTextColor() /*выставление цвета*/

        fab_play.setOnClickListener { /*проигрывать звук при нажатии*/

            Log.i("timerapp", "clicked timer start")

            /*не запускает новый таймер если уже есть активный*/
            if (timer.isCounting) {
                Log.i("timerapp", "ignore duplicate starting request") /**/
                makeToast("Already started")
                return@setOnClickListener
            }

            startTimer() /*запуск таймера*/

        }

        /*при нажатии паузы удаляет прошный таймер*/
        fab_pause.setOnClickListener {
            Log.i("timerapp", "clicked timer pause")

            if (timer.isCounting) {
                makeToast("Pause timer")
                destroyTimer()
                timer.isCounting = false
                timer.isPause = true

            } else {
                /*Ничего не делает если таймер не запущен, нажатие на паузу при неактивном таймере невозможно*/
                makeToast("Already pause")
            }

        }

        /*остановка таймера означает отмену таймера*/
        fab_stop.setOnClickListener {
            Log.i("timerapp", "clicked timer stop(cancel)")
            makeToast("Cancel timer")

            /*если таймер запущен и нажата кнопка отмена, он удаляется*/
            if (timer.isCounting) {
                destroyTimer()
            }

            /*если пауза уже нажата, приложение останавливается, и обновляет подсчёт*/
            timer.resetTimer()
            timer.loadWorkTimer()
            textView_countdown.text = timer.displayTime()
            setTimerTextColor()

        }

        button_set.setOnClickListener {

            Log.i("timerapp", "clicked set button")

            val workTime = editText_pomodoro.text.toString()  /*неизменяемые переменные*/
            val breakTime = editText_break.text.toString() /*неизменяемые переменные*/

            val sharedPref = getPreferences(Context.MODE_PRIVATE) /*неизменяемые переменные*/
            /*сохранение в общих настройках*/
            val editor = sharedPref.edit() /*неизменяемые переменные*/
            editor.putInt("WORK",workTime.toInt())
            editor.putInt("BREAK",breakTime.toInt())
            editor.commit()

            timer.workTimer = if (workTime.equals("")) 2 else workTime.toInt()
            timer.breakTimer = if (breakTime.equals("")) 2 else breakTime.toInt()

            Log.i(
                "timerapp",
                "workTimer set to ${timer.workTimer}, breakTimer set to ${timer.breakTimer}"
            )

            /*если таймер не работает и таймер не поставлен на паузу, отображать время обратного отсчета*/
            if (!timer.isCounting and !timer.isPause){


                timer.loadWorkTimer()
                textView_countdown.text = timer.displayTime()
                textView_countdown.setTextColor(resources.getColor(R.color.colorWork))

                makeToast("Current session: Work ${timer.workTimer} min, break ${timer.breakTimer} min") /*отображение надписи о том сколько проведено в работе и когда перерыв*/

            }else{
                makeToast("Next session: Work ${timer.workTimer} min, break ${timer.breakTimer} min")  /*отображение надписи о том сколько остальсь отдыхать и когда будет второй круг*/
            }

            editText_pomodoro.setText(timer.workTimer.toString()) /*вывод текста*/
            editText_break.setText(timer.breakTimer.toString()) /*вывод текста*/


        }

    }
    /*при выполнение возвращает значение true*/
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_timer, menu)
        return true
    }


    /*Пользователь получает информацию об обратном отсчете в фоновом режиме для обновления обратного отсчета*/
    private val br: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            handleCountDown(intent)
        }
    }

    /*Кнопка продолжить*/
    override fun onResume() {
        super.onResume()
        Log.i("timerapp", "on resume")
        registerReceiver(br, IntentFilter(ForegroundService.COUNTDOWN_BR))

    }
    /*кнопка паузы*/
    override fun onPause() {
        super.onPause()
        Log.i("timerapp", "on pause")
    }
    /*кнопка стоп*/
    override fun onStop() {

        Log.i("timerapp", "on Stop")
        super.onStop()
    }
    /*кнопка выхода*/
    override fun onDestroy() {
        Log.i("timerapp", "on destroy")
        unregisterReceiver(br)

        destroyTimer()
        super.onDestroy()
    }

    /*Таймер остановки можно вызвать когда таймер досчитал до 0 или была нажата пауза*/
    private fun destroyTimer(){

        stopService(Intent(this, ForegroundService::class.java))

        if (wakeLock.isHeld){
            wakeLock.release()
        }

    }

    /*Клавиша назад*/
    override fun onBackPressed() {
        Log.i("timerapp", "on back button")
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }
    /*начало таймера*/
    private fun startTimer() {

        wakeLock.acquire()

        /*проверка работы таймера*/
        when (timer.workState) {

            WorkState.Break -> {
                if (!timer.isPause) {
                    timer.loadBreakTimer()
                }

            }
            WorkState.Work -> {

                /*Загружаем время, если это новый таймер*/
                if (!timer.isCounting and !timer.isPause){
                    timer.loadWorkTimer()
                    Log.i("timerapp", "start a new timer with  ${timer.displayTime()}")
                    makeToast("start a new timer with  ${timer.displayTime()}")

                    /*возобновить отсчет времени, если он уже идет*/
                }else{
                    Log.i("timerapp", "resume timer from  ${timer.displayTime()}")
                    makeToast("Resume with  ${timer.displayTime()}")
                }
            }
        }

        timer.isPause = false /*правда*/
        timer.isCounting = true /*ложь*/
        setTimerTextColor()

        val serviceIntent = Intent(this, ForegroundService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    /*обновление графического интерфейса каждую секунду*/
    private fun handleCountDown(intent: Intent) {

        /*Если таймер остановился не реагировать*/
        if (intent.hasExtra("toCount") && !intent.hasExtra("forceStopped")) {

            timer.minusOneSecond()
            textView_countdown.text = timer.displayTime()
            Log.i("timerapp", timer.displayTime())

            /*если достигло 0*/
            if (!timer.isCounting) {

                destroyTimer()

                /*переключаем состояние по окончании таймера*/
                when (timer.workState) {
                    WorkState.Work -> {

                        completed++
                        textView_completed.setText(completed.toString())
                        sendNotification()

                        timer.workState = WorkState.Break
                        startTimer()
                    }
                    WorkState.Break -> {

                        timer.workState = WorkState.Work
                        startTimer()
                    }
                }
            }
        }
    }
    /*выставление цвета*/
    private fun setTimerTextColor() {
        when (timer.workState) {
            WorkState.Break -> textView_countdown.setTextColor(resources.getColor(R.color.colorBreak))
            WorkState.Work -> textView_countdown.setTextColor(resources.getColor(R.color.colorWork))
        }
    }
    /*Сохранение последнего результата*/
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putLong("timeLeftInSecond", timer.toSeconds())
        outState.putInt("workState", timer.workState.ordinal)
        outState.putBoolean("isCounting", timer.isCounting)
        outState.putBoolean("isPause", timer.isPause)
        outState.putInt("workTimer", timer.workTimer)
        outState.putInt("breakTimer", timer.breakTimer)
    }
    /*Восттановление последнего результата при открытие приложения*/
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        timer.restoreFromSeconds(savedInstanceState.getLong("timeLeftInSecond"))
        timer.workState = WorkState.getValueFromInt(savedInstanceState.getInt("workState"))
        timer.isPause = savedInstanceState.getBoolean("isPause")
        timer.isCounting = savedInstanceState.getBoolean("isCounting")
        timer.workTimer = savedInstanceState.getInt("workTimer")
        timer.breakTimer = savedInstanceState.getInt("breakTimer")

        Log.i("Restore Instance", "timeLeftInSeconds = ${timer.toSeconds()}")
        textView_countdown.text = timer.displayTime()
        setTimerTextColor()


        /*обновление таймера при перезапуске*/
        if (timer.isCounting) {
            startTimer()
        }
    }

}